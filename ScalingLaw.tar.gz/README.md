ScalingLaw
==========

Scaling Law in the Solar Radar, Microwave diagnostic in Fusion, Plasma Stealth, and Plasma Propulsion.
Jiang Dong
